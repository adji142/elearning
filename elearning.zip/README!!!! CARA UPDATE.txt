======================== CARA UPDATE ========================

1. Extract File Update.rar
2. Copy dan replace semua isi Folder Update ke C:/Xampp/htdocs/namaproject
3. Buka phpmyadmin
4. pilih di database projectmu
5. pilih tab sql di phpmyadmin
6. buka file namaproject.sql
7. copy semua isi file kemudian paste di tab sql
8. klik go
9. enjoy

      ======================== CARA UPDATE ========================
======================== SUPPORTEDBY AIS SYSTEM ========================